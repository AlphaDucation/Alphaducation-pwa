Sample lesson template content.
